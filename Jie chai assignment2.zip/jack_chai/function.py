import numpy as np
import scipy
from scipy.interpolate import CubicSpline


# median function
def medianfilter1(input1, filter_length, n):
    """This function can replace the middle n numbers 
    of the input with the median under the given window length

    Args:
        input1 (_list_): _any list_
        filter_length (_int_): _length of window_
        n (_int_): _numbers fo clicks_

    Returns:
        _list_: n modified numbers
    """
    input_list = input1
    start = (filter_length - 1)//2
    stop = (filter_length - 1)//2 + len(input_list)
    input_padding = [0 for _ in range(len(input_list) + filter_length - 1)]
    input_padding[start:stop] = input_list

    mid = (filter_length - 1)//2

    # print(input_padding)
    i = 0

    new = input_list
    while i < len(input_list):
        b = sorted(input_padding[i:i + filter_length])
        # print(b)
        #input_list[i]= b[mid]
        new[i] = b[mid]
        i = i + 1

    return new[mid: mid + n]


# aduio median filter
def aduiomedianfilter(input, location, odd):
    """_audio median filter_

    Args:
        input (_list_): _any list which has clicks_
        location (_list_): _location of clicks_
        odd (_int_): _control length of filter_

    Returns:
        _list_: _restored  list_
    """
    if odd % 2 == 0:
        print('error: please input an add number')
    else:
        i = 0
        newlist = input
        while i < len(input):
            if location[i] != 0:
                n = 1
                while True:
                    if location[i + n] != 0:
                        n = n+1
                        continue
                    else:
                        break

                windowlen = 2 * n + odd
                t = (windowlen-1)//2
                newlist[i:i +
                        n] = medianfilter1(input[i-t: i+n+t], windowlen, n)
                i = i + n
            else:
                newlist[i] = input[i]
                i = i + 1

    return newlist

# cubic filter


def cubic(input1, windowlen, n):
    """_The function of this filer is that replace the clicks by inerpolated number.
    I use the CubicSpline to realize interpolation

    Args:
        input1 (_type_): _description_
        windowlen (_type_): _description_
        n (_type_): _description_

    Returns:
        _type_: _description_
    """
    t = (windowlen-1)//2
    input2 = input1
    j = 0
    y = [0]*(len(input2)-n)
    i = 0
    while i < len(input2):
        if i >= n and i < t+n:
            i = i+1
            continue
        else:
            y[j] = input2[i]
            i = i+1
            j = j+1
            continue

    x = np.arange(0, 2*t, 1)
    f = CubicSpline(x, y, bc_type='natural')
    x_new = np.linspace(t, t+1, n)
    y_new = f(x_new)

    return y_new

# aduio cublic filter


def aduiocublicfilter(input, location):
    """_audio filter which uses CubicFilter function to remove clicks_

    Args:
        input (_list_): _any list which has clicks_
        location (_list_): _location of clicks_

    Returns:
        _list_: _restored  list_
    """

    i = 0
    newlist = input
    while i < len(input):
        if location[i] == 0:
            newlist[i] = input[i]
            i = i+1
        else:
            n = 1
            while True:
                if location[i + n] != 0:
                    n = n+1
                    continue
                else:
                    break
            windowlen = 2 * n + 1
            t = (windowlen-1)//2

            newlist[i:i + n] = cubic(input[i-t: i+n+t], windowlen, n)
            i = i+n

    return newlist
