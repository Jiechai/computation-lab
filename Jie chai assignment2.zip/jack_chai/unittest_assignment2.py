import unittest
import numpy as np
import function 
class TestMyCode(unittest.TestCase):
    def test_medianfilter1(self):
        data_for_test = [3,14,5]
        data = [5]
        result = function.medianfilter1(data_for_test, 3, 1)
        self.assertEqual(result, data)
        
        
if __name__ =='__main__':
    unittest.main()