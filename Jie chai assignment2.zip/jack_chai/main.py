import numpy as np
import scipy
from scipy.io import wavfile
from scipy.interpolate import CubicSpline
import matplotlib
import matplotlib.pyplot as plt
import function         # Self-built function library
import time
from tqdm import tqdm

# read wav file and difine some necessary variables
# Please change to the actual location of the file
filename1 = 'D:\Microsoft VS Code\jack_chai\pyclean.wav'     # clean.wav location
filename2 = 'D:\Microsoft VS Code\jack_chai\pydetection.wav'  # detection file location
filename3 = 'D:\Microsoft VS Code\jack_chai\pydegraded.wav'  # degraded file location
filename4 = 'D:\Microsoft VS Code\jack_chai\ restore1.wav'  # restored file location 1
filename5 = 'D:\Microsoft VS Code\jack_chai\ restore2.wav'  # restored file location 2

fs, a = scipy.io.wavfile.read(filename1)    # read clean.wav
fs, bk = scipy.io.wavfile.read(filename2)   # read detection.wav
fs, y = scipy.io.wavfile.read(filename3)    # read degraded.wav

'''
task1: using  our own median function to remove clicks
'''
# Call the median filter once.
medianoutput1 = function.aduiomedianfilter(y, bk, 1)

'''
I found that if I don't change the original data when the filter is moving, 
there will be a bug: a few clicks move the position.

Strategy: Call the filter again to filter out most of the clicks. 
(Of course, the modification function can also be implemented, e.g.
changing the window length, or using the updated data to continue to move the window)
'''
c = medianoutput1 - a
dec = c * 0
for i in tqdm(range(len(c))):
    if abs(c[i]) > 2500:
        dec[i] = 1
    else:
        continue
print('done')
# Call the median filter again.
medianoutput2 = function.aduiomedianfilter(medianoutput1, dec, 1)
mse1 = np.square(np.subtract(a, medianoutput2)).mean()
print('mse1=', mse1)
wavfile.write(filename4, fs, medianoutput2)

'''
task2: using Cublicspline function to remove clicks
'''
splineoutput1 = function.aduiocublicfilter(
    y, bk)  # Call the spline filter once.

'''
Similar issue, clicks are not fully removed on the image. 
Calling again can improve the filtering effect.
'''
diff = splineoutput1 - a
dec = diff * 0
for i in tqdm(range(len(c))):
    if abs(c[i]) > 5000:
        dec[i] = 1
    else:
        continue
print('done')
splineoutput2 = function.aduiocublicfilter(splineoutput1, dec)
mse2 = np.square(np.subtract(a, medianoutput2)).mean()
print('mse2=', mse2)
wavfile.write('D:\Microsoft VS Code\jack_chai\ restore2.wav',
              fs, splineoutput2)


t=np.arange(0,len(a),1)

plt.figure(figsize=(8,8), dpi=80)
plt.figure(1)
ax1 = plt.subplot(411)
ax1.plot(t,a, color="r",linestyle = "-")
ax2 = plt.subplot(412)
ax2.plot(t,y,color="y",linestyle = "-")
ax3 = plt.subplot(413)
ax3.plot(t,bk,color="g",linestyle = "-")
ax4 = plt.subplot(414)
ax4.plot(t,medianoutput2,color="b",linestyle = "-")

plt.savefig("median.png")
plt.show()

plt.figure(figsize=(8,8), dpi=80)
plt.figure(1)
ax1 = plt.subplot(411)
ax1.plot(t,y, color="r",linestyle = "-")
ax2 = plt.subplot(412)
ax2.plot(t,y,color="y",linestyle = "-")
ax3 = plt.subplot(413)
ax3.plot(t,bk,color="g",linestyle = "-")
ax4 = plt.subplot(414)
ax4.plot(t,splineoutput2,color="b",linestyle = "-")

plt.savefig("spline.png")
plt.show()