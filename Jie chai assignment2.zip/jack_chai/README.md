# EEP55C22 Assignment II Audio Rstoration in Python
Jie chai  22312919  e-mail:jcahi@tcd.ie


## High-level Description of the project
This assignment builds on Assignment I. We assume that we have successfully detected the clicks and we are applying different interpolation methods to restore the audio, such as
- median filtering
- cubic splines

---

## Installation and Execution

Provide details on the Python version and libraries (e.g. numpy version) you are using. One easy way to do it is to do that automatically:
```sh                                 
pip3 install numpy
pip3 install scipy
pip3 install ntqdm
pip3 install matplotlib
```
For more details check [here](https://github.com/Jiechai/computation-lab)


Afer installing all required packages you can run the demo file simply by typing:
```sh
python main.py
```
---

## Methodology and Results
My main.py structure:
1. import the necessary libraries
2. Copy the existing clean.wav file, detection.wav file, and degraded file.
3. part1: I use a median filter to remove clip noise. The median filter function is to input the degraded audio and detection files, and return the restored1 file. Then save it in the same folder.Here I am calling the median filter twice.
4. part2: I use a cubic spline interpolation filter to eliminate clip noise. The cubic spline interpolation function filter function is to input the degraded audio and detection files, return the restored2 file, and then save it to the same folder. Here I also call it twice.

My function labrary structure:

1. aduiomedianfilter: The input is noisy data, noise detection file, and a window length control variable odd. Check whether the window length control variable is an odd number. Otherwise, the program is interrupted and an error report is returned. If the result is odd, continue. Traverse the position of click in each detection, if there is no click, save the value of the position in the returned newlist. If there is a click, detect the number of consecutive clicks and record it as n. The window length is determined to be 2n+odd. The intermediate variable t is equal to 0.5*(window length-1)
Then filter the list with a length of n+2t and click. Return the replaced clicks value to newlist.Finally return the entire newlist.

2. medianfilter1: Median value filter function, input list, and window length, returns the middle N numbers replaced by the median.Structure: pad zero at the end; traverse i, sort, and take the middle value; return the median.

3. audiopublicfilter: Input noisy audio, and position file, returns noise-free file.Structure: traverse all i, keep no noise, replace with cubic spline function if there is noise; return the entire list.
4. Cubic function: input list, window length, and number of noises. Returns N replaced values.tructure: remove the noise value in the input list to form a new list; insert n values in the middle of the new list. and return.






**Results**

1. the results of the two methods<img src="median.png" ><img src="spline.png" >

2. Comparing the two different interpolation methods, we notice that method cublicspline achieves a lower MSE. The runtime of median method is lower
<img src="result.png" >

After listening to the two restored files, we notice noise is still present but suppressed.


---
## Credits

This code was developed for purely academic purposes by computation-lab as part of the module.

Resources:
- https://github.com/Jiechai/computation-lab






